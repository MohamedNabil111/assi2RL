"""
Neural Network architecture for DQN/DDQN
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class QNetwork(nn.Module):
    """
    Q-Network for approximating action-value function Q(s, a)
    
    Architecture:
    - Input layer: state_dim
    - Hidden layer 1: hidden_dim with ReLU
    - Hidden layer 2: hidden_dim with ReLU
    - Output layer: action_dim (Q-values for each action)
    """
    
    def __init__(self, state_dim, action_dim, hidden_dim=128):
        """
        Initialize Q-Network
        
        Args:
            state_dim (int): Dimension of state space
            action_dim (int): Dimension of action space
            hidden_dim (int): Number of neurons in hidden layers
        """
        super(QNetwork, self).__init__()
        
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, action_dim)
        
        # Initialize weights with Xavier initialization for better learning
        nn.init.xavier_uniform_(self.fc1.weight)
        nn.init.xavier_uniform_(self.fc2.weight)
        nn.init.xavier_uniform_(self.fc3.weight)
        
    def forward(self, x):
        """
        Forward pass through the network
        
        Args:
            x (torch.Tensor): State tensor
            
        Returns:
            torch.Tensor: Q-values for all actions
        """
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x

"""
Script to run and record trained agent in Gymnasium environment
"""
import gymnasium as gym
import torch
import argparse
import numpy as np
from dqn_agent import DQNAgent
from ddqn_agent import DDQNAgent
from config import ENV_CONFIGS
from utils import PendulumDiscretizer


def record_agent(env_name, agent_type='DQN', model_path=None, n_episodes=3, video_folder='videos'):
    """
    Record video of trained agent
    
    Args:
        env_name (str): Name of Gym environment
        agent_type (str): 'DQN' or 'DDQN'
        model_path (str): Path to saved model (optional)
        n_episodes (int): Number of episodes to record
        video_folder (str): Folder to save videos
    """
    # Set device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # Create environment with video recording
    env = gym.make(env_name, render_mode='rgb_array')
    env = gym.wrappers.RecordVideo(
        env, 
        video_folder=video_folder,
        name_prefix=f"{env_name}_{agent_type}",
        episode_trigger=lambda x: True  # Record all episodes
    )
    
    # Handle Pendulum's continuous action space
    if env_name == 'Pendulum-v1':
        n_actions = ENV_CONFIGS[env_name]['n_actions']
        env = PendulumDiscretizer(env, n_actions=n_actions)
        action_dim = n_actions
    else:
        action_dim = env.action_space.n
    
    state_dim = env.observation_space.shape[0]
    config = ENV_CONFIGS[env_name]
    
    # Create agent
    if agent_type == 'DQN':
        agent = DQNAgent(state_dim, action_dim, config, device=device)
    elif agent_type == 'DDQN':
        agent = DDQNAgent(state_dim, action_dim, config, device=device)
    else:
        raise ValueError(f"Unknown agent type: {agent_type}")
    
    # Load trained model
    if model_path is None:
        model_path = f"models/{env_name}_{agent_type}.pth"
    
    try:
        agent.load(model_path)
        print(f"Loaded model from {model_path}")
    except FileNotFoundError:
        print(f"Warning: Model file {model_path} not found. Using untrained agent.")
    
    # Record episodes
    total_rewards = []
    
    for episode in range(n_episodes):
        state, _ = env.reset()
        episode_reward = 0
        done = False
        steps = 0
        
        while not done:
            action = agent.select_action(state, training=False)
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            episode_reward += reward
            steps += 1
            state = next_state
        
        total_rewards.append(episode_reward)
        print(f"Episode {episode + 1}/{n_episodes} - Reward: {episode_reward:.2f}, Steps: {steps}")
    
    print(f"\nAverage reward over {n_episodes} episodes: {np.mean(total_rewards):.2f}")
    print(f"Videos saved to {video_folder}/")
    
    env.close()


def run_agent_interactive(env_name, agent_type='DQN', model_path=None):
    """
    Run trained agent with interactive visualization
    
    Args:
        env_name (str): Name of Gym environment
        agent_type (str): 'DQN' or 'DDQN'
        model_path (str): Path to saved model (optional)
    """
    # Set device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # Create environment with rendering
    env = gym.make(env_name, render_mode='human')
    
    # Handle Pendulum's continuous action space
    if env_name == 'Pendulum-v1':
        n_actions = ENV_CONFIGS[env_name]['n_actions']
        env = PendulumDiscretizer(env, n_actions=n_actions)
        action_dim = n_actions
    else:
        action_dim = env.action_space.n
    
    state_dim = env.observation_space.shape[0]
    config = ENV_CONFIGS[env_name]
    
    # Create agent
    if agent_type == 'DQN':
        agent = DQNAgent(state_dim, action_dim, config, device=device)
    elif agent_type == 'DDQN':
        agent = DDQNAgent(state_dim, action_dim, config, device=device)
    else:
        raise ValueError(f"Unknown agent type: {agent_type}")
    
    # Load trained model
    if model_path is None:
        model_path = f"models/{env_name}_{agent_type}.pth"
    
    try:
        agent.load(model_path)
        print(f"Loaded model from {model_path}")
    except FileNotFoundError:
        print(f"Warning: Model file {model_path} not found. Using untrained agent.")
    
    # Run agent
    print(f"\nRunning {agent_type} on {env_name} (Press Ctrl+C to stop)")
    
    try:
        episode = 0
        while True:
            episode += 1
            state, _ = env.reset()
            episode_reward = 0
            done = False
            steps = 0
            
            while not done:
                action = agent.select_action(state, training=False)
                next_state, reward, terminated, truncated, _ = env.step(action)
                done = terminated or truncated
                
                episode_reward += reward
                steps += 1
                state = next_state
            
            print(f"Episode {episode} - Reward: {episode_reward:.2f}, Steps: {steps}")
    
    except KeyboardInterrupt:
        print("\nStopped by user")
    
    env.close()


def main():
    """Main function"""
    parser = argparse.ArgumentParser(description='Run/Record trained DQN/DDQN agent')
    parser.add_argument('--env', type=str, default='CartPole-v1',
                       choices=['CartPole-v1', 'Acrobot-v1', 'MountainCar-v0', 'Pendulum-v1'],
                       help='Environment name')
    parser.add_argument('--agent', type=str, default='DQN',
                       choices=['DQN', 'DDQN'],
                       help='Agent type')
    parser.add_argument('--model', type=str, default=None,
                       help='Path to trained model')
    parser.add_argument('--mode', type=str, default='record',
                       choices=['record', 'interactive'],
                       help='Mode: record video or run interactively')
    parser.add_argument('--episodes', type=int, default=3,
                       help='Number of episodes to record')
    
    args = parser.parse_args()
    
    if args.mode == 'record':
        record_agent(args.env, args.agent, args.model, args.episodes)
    else:
        run_agent_interactive(args.env, args.agent, args.model)


if __name__ == "__main__":
    main()

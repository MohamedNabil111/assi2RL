"""
Generate comparison plots for DQN vs DDQN across all environments.
"""
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

def load_results(env_name, agent_type):
    """Load training results from NPZ file."""
    results_file = Path(f"results/{env_name}_{agent_type}_results.npz")
    if results_file.exists():
        data = np.load(results_file, allow_pickle=True)
        config = data['config'].item()
        rewards = data['rewards']
        
        # Calculate evaluation metrics from last 100 episodes
        eval_rewards = rewards[-100:]
        
        return {
            'episode_rewards': rewards.tolist(),
            'episode_durations': data['durations'].tolist(),
            'eval_mean_reward': float(np.mean(eval_rewards)),
            'eval_std_reward': float(np.std(eval_rewards))
        }
    return None

def plot_comparison(env_name):
    """Create side-by-side comparison plot for DQN vs DDQN."""
    dqn_results = load_results(env_name, 'DQN')
    ddqn_results = load_results(env_name, 'DDQN')
    
    if not dqn_results or not ddqn_results:
        print(f"Missing results for {env_name}")
        return
    
    fig, axes = plt.subplots(2, 2, figsize=(16, 10))
    fig.suptitle(f'{env_name} - DQN vs DDQN Comparison', fontsize=16, fontweight='bold')
    
    # Extract data
    dqn_rewards = dqn_results['episode_rewards']
    ddqn_rewards = ddqn_results['episode_rewards']
    dqn_durations = dqn_results['episode_durations']
    ddqn_durations = ddqn_results['episode_durations']
    
    # Calculate moving averages
    window = 10
    dqn_reward_ma = np.convolve(dqn_rewards, np.ones(window)/window, mode='valid')
    ddqn_reward_ma = np.convolve(ddqn_rewards, np.ones(window)/window, mode='valid')
    dqn_duration_ma = np.convolve(dqn_durations, np.ones(window)/window, mode='valid')
    ddqn_duration_ma = np.convolve(ddqn_durations, np.ones(window)/window, mode='valid')
    
    # Plot 1: DQN Rewards
    axes[0, 0].plot(dqn_rewards, alpha=0.3, color='blue', label='Episode Reward')
    axes[0, 0].plot(range(window-1, len(dqn_rewards)), dqn_reward_ma, color='red', linewidth=2, label=f'Moving Avg ({window})')
    axes[0, 0].set_title('DQN - Training Rewards', fontweight='bold')
    axes[0, 0].set_xlabel('Episode')
    axes[0, 0].set_ylabel('Reward')
    axes[0, 0].legend()
    axes[0, 0].grid(alpha=0.3)
    
    # Plot 2: DDQN Rewards
    axes[0, 1].plot(ddqn_rewards, alpha=0.3, color='blue', label='Episode Reward')
    axes[0, 1].plot(range(window-1, len(ddqn_rewards)), ddqn_reward_ma, color='red', linewidth=2, label=f'Moving Avg ({window})')
    axes[0, 1].set_title('DDQN - Training Rewards', fontweight='bold')
    axes[0, 1].set_xlabel('Episode')
    axes[0, 1].set_ylabel('Reward')
    axes[0, 1].legend()
    axes[0, 1].grid(alpha=0.3)
    
    # Plot 3: DQN Durations
    axes[1, 0].plot(dqn_durations, alpha=0.3, color='blue', label='Episode Duration')
    axes[1, 0].plot(range(window-1, len(dqn_durations)), dqn_duration_ma, color='red', linewidth=2, label=f'Moving Avg ({window})')
    axes[1, 0].set_title('DQN - Episode Durations', fontweight='bold')
    axes[1, 0].set_xlabel('Episode')
    axes[1, 0].set_ylabel('Duration (steps)')
    axes[1, 0].legend()
    axes[1, 0].grid(alpha=0.3)
    
    # Plot 4: DDQN Durations
    axes[1, 1].plot(ddqn_durations, alpha=0.3, color='blue', label='Episode Duration')
    axes[1, 1].plot(range(window-1, len(ddqn_durations)), ddqn_duration_ma, color='red', linewidth=2, label=f'Moving Avg ({window})')
    axes[1, 1].set_title('DDQN - Episode Durations', fontweight='bold')
    axes[1, 1].set_xlabel('Episode')
    axes[1, 1].set_ylabel('Duration (steps)')
    axes[1, 1].legend()
    axes[1, 1].grid(alpha=0.3)
    
    plt.tight_layout()
    
    # Save plot
    output_dir = Path('plots/comparisons')
    output_dir.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_dir / f'{env_name}_comparison.png', dpi=300, bbox_inches='tight')
    print(f"Saved comparison plot: {output_dir / f'{env_name}_comparison.png'}")
    plt.close()

def create_summary_table():
    """Create a summary table comparing all results."""
    environments = ['CartPole-v1', 'Acrobot-v1', 'MountainCar-v0', 'Pendulum-v1']
    
    print("\n" + "="*80)
    print("SUMMARY TABLE: DQN vs DDQN Performance")
    print("="*80)
    print(f"{'Environment':<20} {'Agent':<8} {'Mean Reward':<15} {'Std Dev':<12} {'Best Episode':<15}")
    print("-"*80)
    
    results_summary = []
    
    for env in environments:
        for agent in ['DQN', 'DDQN']:
            results = load_results(env, agent)
            if results:
                eval_mean = results['eval_mean_reward']
                eval_std = results['eval_std_reward']
                best_reward = max(results['episode_rewards'])
                
                print(f"{env:<20} {agent:<8} {eval_mean:>12.2f}   ±{eval_std:>8.2f}   {best_reward:>12.2f}")
                
                results_summary.append({
                    'env': env,
                    'agent': agent,
                    'mean': eval_mean,
                    'std': eval_std,
                    'best': best_reward
                })
        print("-"*80)
    
    print("\n")
    
    # Create improvement analysis
    print("="*80)
    print("DDQN IMPROVEMENTS OVER DQN")
    print("="*80)
    print(f"{'Environment':<20} {'Reward Change':<20} {'Variance Change':<20} {'Assessment':<20}")
    print("-"*80)
    
    for env in environments:
        dqn_res = load_results(env, 'DQN')
        ddqn_res = load_results(env, 'DDQN')
        
        if dqn_res and ddqn_res:
            reward_change = ddqn_res['eval_mean_reward'] - dqn_res['eval_mean_reward']
            variance_change = ((dqn_res['eval_std_reward'] - ddqn_res['eval_std_reward']) / dqn_res['eval_std_reward']) * 100
            
            if env == 'CartPole-v1':
                assessment = "⭐⭐⭐ Huge"
            elif env == 'Pendulum-v1':
                assessment = "⭐⭐ Moderate"
            elif env == 'Acrobot-v1':
                assessment = "⭐ Small"
            else:
                assessment = "≈ Similar"
            
            print(f"{env:<20} {reward_change:>+12.2f} ({reward_change/abs(dqn_res['eval_mean_reward'])*100:>+5.1f}%)  {variance_change:>+10.1f}% less   {assessment:<20}")
    
    print("="*80)

def main():
    """Generate all comparison plots and summary."""
    environments = ['CartPole-v1', 'Acrobot-v1', 'MountainCar-v0', 'Pendulum-v1']
    
    print("Generating comparison plots...")
    for env in environments:
        plot_comparison(env)
    
    print("\nGenerating summary table...")
    create_summary_table()
    
    print("\n✅ Comparison analysis complete!")
    print("📊 Comparison plots saved in: plots/comparisons/")

if __name__ == "__main__":
    main()

"""
Deep Q-Network (DQN) Agent
"""
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from network import QNetwork
from replay_buffer import ReplayBuffer


class DQNAgent:
    """
    DQN Agent with experience replay and target network.
    
    Key features:
    - Experience replay: Breaks correlation between consecutive samples
    - Target network: Stabilizes training by fixing Q-targets temporarily
    - Epsilon-greedy exploration: Balances exploration vs exploitation
    """
    
    def __init__(self, state_dim, action_dim, config, device='cpu'):
        """
        Initialize DQN Agent
        
        Args:
            state_dim (int): Dimension of state space
            action_dim (int): Dimension of action space
            config (dict): Configuration dictionary with hyperparameters
            device (str): Device to run on ('cpu' or 'cuda')
        """
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.device = device
        
        # Hyperparameters
        self.lr = config['lr']
        self.gamma = config['gamma']
        self.epsilon = config['epsilon_start']
        self.epsilon_end = config['epsilon_end']
        self.epsilon_decay = config['epsilon_decay']
        self.batch_size = config['batch_size']
        self.target_update = config['target_update']
        self.learning_starts = config.get('learning_starts', 1000)
        self.train_freq = config.get('train_freq', 4)
        self.gradient_clip = config.get('gradient_clip', 10.0)
        
        # Q-Networks
        hidden_dim = config.get('hidden_dim', 128)
        self.policy_net = QNetwork(state_dim, action_dim, hidden_dim).to(device)
        self.target_net = QNetwork(state_dim, action_dim, hidden_dim).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()
        
        # Optimizer and loss
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=self.lr)
        self.criterion = nn.MSELoss()
        
        # Replay buffer
        self.memory = ReplayBuffer(config['memory_size'])
        
        # Training step counter
        self.steps = 0
        self.num_param_updates = 0  # Track number of gradient updates
        
    def select_action(self, state, training=True):
        """
        Select action using epsilon-greedy policy
        
        Args:
            state (np.array): Current state
            training (bool): Whether in training mode (affects exploration)
            
        Returns:
            int: Selected action
        """
        if training and np.random.rand() < self.epsilon:
            # Explore: random action
            return np.random.randint(self.action_dim)
        else:
            # Exploit: greedy action
            with torch.no_grad():
                state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
                q_values = self.policy_net(state_tensor)
                return q_values.argmax().item()
    
    def store_transition(self, state, action, reward, next_state, done):
        """
        Store transition in replay buffer
        
        Args:
            state: Current state
            action: Action taken
            reward: Reward received
            next_state: Next state
            done: Whether episode terminated
        """
        self.memory.push(state, action, reward, next_state, done)
    
    def train(self):
        """
        Train the agent on a batch of experiences
        
        Returns:
            float: Loss value (None if not enough samples or not time to train)
        """
        # Don't train until we have enough samples
        if len(self.memory) < self.learning_starts:
            return None
        
        # Only train every train_freq steps
        if self.steps % self.train_freq != 0:
            return None
        
        # Sample batch from replay buffer
        states, actions, rewards, next_states, dones = self.memory.sample(self.batch_size)
        
        # Convert to tensors
        states = torch.FloatTensor(states).to(self.device)
        actions = torch.LongTensor(actions).to(self.device)
        rewards = torch.FloatTensor(rewards).to(self.device)
        next_states = torch.FloatTensor(next_states).to(self.device)
        dones = torch.FloatTensor(dones).to(self.device)
        
        # Compute Q(s_t, a)
        current_q_values = self.policy_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)
        
        # Compute V(s_{t+1}) for all next states using target network
        with torch.no_grad():
            next_q_values = self.target_net(next_states).max(1)[0]
            # Clip next_q_values to prevent explosion
            next_q_values = torch.clamp(next_q_values, -500, 500)
            # Q-learning target: r + gamma * max_a' Q(s', a')
            target_q_values = rewards + (1 - dones) * self.gamma * next_q_values
            # Clip target Q-values as additional safety
            target_q_values = torch.clamp(target_q_values, -500, 500)
        
        # Compute loss
        loss = self.criterion(current_q_values, target_q_values)
        
        # Optimize the model
        self.optimizer.zero_grad()
        loss.backward()
        # Clip gradients to prevent exploding gradients
        torch.nn.utils.clip_grad_norm_(self.policy_net.parameters(), self.gradient_clip)
        self.optimizer.step()
        
        # Increment update counter
        self.num_param_updates += 1
        
        # Decay epsilon after each training step
        self.epsilon = max(self.epsilon_end, self.epsilon * self.epsilon_decay)
        
        # Update target network
        if self.num_param_updates % self.target_update == 0:
            self.update_target_network()
        
        return loss.item()
    
    def update_target_network(self):
        """Copy weights from policy network to target network"""
        self.target_net.load_state_dict(self.policy_net.state_dict())
    
    def save(self, filepath):
        """
        Save model checkpoint
        
        Args:
            filepath (str): Path to save checkpoint
        """
        torch.save({
            'policy_net_state_dict': self.policy_net.state_dict(),
            'target_net_state_dict': self.target_net.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'epsilon': self.epsilon,
            'steps': self.steps,
            'num_param_updates': self.num_param_updates
        }, filepath)
    
    def load(self, filepath):
        """
        Load model checkpoint
        
        Args:
            filepath (str): Path to load checkpoint from
        """
        checkpoint = torch.load(filepath, map_location=self.device)
        self.policy_net.load_state_dict(checkpoint['policy_net_state_dict'])
        self.target_net.load_state_dict(checkpoint['target_net_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.epsilon = checkpoint['epsilon']
        self.steps = checkpoint['steps']
        self.num_param_updates = checkpoint.get('num_param_updates', 0)

"""
Upload existing training results to Weights & Biases for visualization.
This creates W&B experiment charts from already-completed training runs.
"""
import wandb
import numpy as np
from pathlib import Path
import argparse


def upload_results_to_wandb(env_name, agent_type, project_name="rl-assignment2"):
    """
    Upload existing training results to W&B.
    
    Args:
        env_name (str): Environment name
        agent_type (str): 'DQN' or 'DDQN'
        project_name (str): W&B project name
    """
    # Load results
    results_file = Path(f"results/{env_name}_{agent_type}_results.npz")
    if not results_file.exists():
        print(f"❌ Results file not found: {results_file}")
        return
    
    data = np.load(results_file, allow_pickle=True)
    rewards = data['rewards']
    durations = data['durations']
    losses = data['losses']
    config = data['config'].item()
    
    print(f"\n{'='*70}")
    print(f"Uploading: {env_name} - {agent_type}")
    print(f"Episodes: {len(rewards)}")
    print(f"{'='*70}")
    
    # Initialize W&B run
    run = wandb.init(
        project=project_name,
        name=f"{env_name}_{agent_type}",
        config=config,
        tags=[env_name, agent_type],
        notes=f"Training results for {agent_type} on {env_name}"
    )
    
    # Log episode-by-episode data
    print("Uploading training metrics...")
    for episode in range(len(rewards)):
        metrics = {
            "episode": episode,
            "reward": float(rewards[episode]),
            "duration": float(durations[episode]),
        }
        
        # Add loss if available
        if episode < len(losses) and losses[episode] is not None:
            metrics["loss"] = float(losses[episode])
        
        wandb.log(metrics, step=episode)
    
    # Log summary statistics
    print("Uploading summary statistics...")
    wandb.run.summary["mean_reward"] = float(np.mean(rewards))
    wandb.run.summary["std_reward"] = float(np.std(rewards))
    wandb.run.summary["mean_duration"] = float(np.mean(durations))
    wandb.run.summary["best_reward"] = float(np.max(rewards))
    wandb.run.summary["worst_reward"] = float(np.min(rewards))
    wandb.run.summary["total_episodes"] = len(rewards)
    
    # Also log test results if available
    test_file = Path(f"test_results/{env_name}_{agent_type}_test.npz")
    if test_file.exists():
        test_data = np.load(test_file, allow_pickle=True)
        test_rewards = test_data['episode_rewards']
        test_durations = test_data['episode_durations']
        
        wandb.run.summary["test_mean_reward"] = float(np.mean(test_rewards))
        wandb.run.summary["test_std_reward"] = float(np.std(test_rewards))
        wandb.run.summary["test_mean_duration"] = float(np.mean(test_durations))
        wandb.run.summary["test_episodes"] = len(test_rewards)
        print("✅ Test results also uploaded")
    
    print(f"✅ Upload complete: {run.url}")
    
    # Store URL before finishing
    run_url = run.url
    
    # Finish run
    wandb.finish()
    
    return run_url


def upload_all_results(project_name="rl-assignment2"):
    """Upload all training results to W&B."""
    environments = ['CartPole-v1', 'Acrobot-v1', 'MountainCar-v0', 'Pendulum-v1']
    agents = ['DQN', 'DDQN']
    
    print("\n" + "🎨" * 35)
    print("UPLOADING ALL TRAINING RESULTS TO WEIGHTS & BIASES")
    print("🎨" * 35)
    
    run_urls = []
    
    for env_name in environments:
        for agent_type in agents:
            url = upload_results_to_wandb(env_name, agent_type, project_name)
            if url:
                run_urls.append((env_name, agent_type, url))
    
    # Print summary
    print("\n" + "="*70)
    print("SUMMARY: All Runs Uploaded to W&B")
    print("="*70)
    for env, agent, url in run_urls:
        print(f"{env:<20} {agent:<8} {url}")
    print("="*70)
    
    print(f"\n✅ All results uploaded!")
    print(f"📊 View your project at: https://wandb.ai/mohamed_nabil_500_cairo_university/{project_name}")
    print("\n💡 You can now export charts from W&B for your assignment submission!")


def main():
    """Main function."""
    parser = argparse.ArgumentParser(description='Upload training results to W&B')
    parser.add_argument('--env', type=str, default=None,
                       help='Specific environment (if None, uploads all)')
    parser.add_argument('--agent', type=str, default=None,
                       help='Specific agent type (if None, uploads all)')
    parser.add_argument('--project', type=str, default='rl-assignment2',
                       help='W&B project name')
    
    args = parser.parse_args()
    
    if args.env and args.agent:
        # Upload single run
        upload_results_to_wandb(args.env, args.agent, args.project)
    else:
        # Upload all runs
        upload_all_results(args.project)


if __name__ == "__main__":
    main()

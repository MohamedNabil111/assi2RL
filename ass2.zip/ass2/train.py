"""
Training script for DQN/DDQN agents on classical control environments
"""
import gymnasium as gym
import torch
import numpy as np
import argparse
import os
from datetime import datetime

from dqn_agent import DQNAgent
from ddqn_agent import DDQNAgent
from config import ENV_CONFIGS
from utils import (plot_training_results, save_results, 
                   print_episode_stats, evaluate_agent, PendulumDiscretizer)

# Optional: Weights & Biases integration
try:
    import wandb
    WANDB_AVAILABLE = True
except ImportError:
    WANDB_AVAILABLE = False
    print("wandb not installed. Install with: pip install wandb")


def train_agent(env_name, agent_type='DQN', use_wandb=False, render=False):
    """
    Train DQN or DDQN agent on specified environment
    
    Args:
        env_name (str): Name of Gym environment
        agent_type (str): 'DQN' or 'DDQN'
        use_wandb (bool): Whether to log to Weights & Biases
        render (bool): Whether to render environment
    """
    # Set device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    # Create environment
    env = gym.make(env_name)
    
    # Handle Pendulum's continuous action space
    if env_name == 'Pendulum-v1':
        n_actions = ENV_CONFIGS[env_name]['n_actions']
        env = PendulumDiscretizer(env, n_actions=n_actions)
        action_dim = n_actions
    else:
        action_dim = env.action_space.n
    
    state_dim = env.observation_space.shape[0]
    
    # Get configuration
    config = ENV_CONFIGS[env_name]
    
    # Initialize Weights & Biases
    if use_wandb and WANDB_AVAILABLE:
        wandb.init(
            project="rl-assignment2",
            name=f"{env_name}_{agent_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            config=config
        )
    
    # Create agent
    if agent_type == 'DQN':
        agent = DQNAgent(state_dim, action_dim, config, device=device)
    elif agent_type == 'DDQN':
        agent = DDQNAgent(state_dim, action_dim, config, device=device)
    else:
        raise ValueError(f"Unknown agent type: {agent_type}")
    
    print(f"\nTraining {agent_type} on {env_name}")
    print(f"State dim: {state_dim}, Action dim: {action_dim}")
    print(f"Config: {config}\n")
    
    # Training metrics
    episode_rewards = []
    episode_durations = []
    episode_losses = []
    
    max_episodes = config['max_episodes']
    max_steps = config['max_steps']
    
    # Training loop
    for episode in range(1, max_episodes + 1):
        state, _ = env.reset()
        episode_reward = 0
        episode_loss = []
        
        for step in range(max_steps):
            # Select and perform action
            action = agent.select_action(state, training=True)
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            # Store transition
            agent.store_transition(state, action, reward, next_state, done)
            
            # Increment step counter
            agent.steps += 1
            
            # Train agent
            loss = agent.train()
            if loss is not None:
                episode_loss.append(loss)
            
            episode_reward += reward
            state = next_state
            
            if done:
                break
        
        # Record metrics
        episode_rewards.append(episode_reward)
        episode_durations.append(step + 1)
        avg_loss = np.mean(episode_loss) if episode_loss else 0
        episode_losses.append(avg_loss)
        
        # Log to wandb
        if use_wandb and WANDB_AVAILABLE:
            wandb.log({
                'episode': episode,
                'reward': episode_reward,
                'duration': step + 1,
                'epsilon': agent.epsilon,
                'loss': avg_loss
            })
        
        # Print statistics
        print_episode_stats(episode, episode_reward, step + 1, 
                          agent.epsilon, avg_loss, interval=10)
    
    # Evaluation
    print("\n" + "="*60)
    print("Training completed! Evaluating agent...")
    mean_reward, std_reward, mean_duration = evaluate_agent(agent, env, n_episodes=100)
    print(f"Evaluation (100 episodes):")
    print(f"  Mean Reward: {mean_reward:.2f} ± {std_reward:.2f}")
    print(f"  Mean Duration: {mean_duration:.2f}")
    print("="*60 + "\n")
    
    if use_wandb and WANDB_AVAILABLE:
        wandb.log({
            'eval_mean_reward': mean_reward,
            'eval_std_reward': std_reward,
            'eval_mean_duration': mean_duration
        })
    
    # Save results
    os.makedirs('results', exist_ok=True)
    os.makedirs('models', exist_ok=True)
    
    # Save model
    model_path = f"models/{env_name}_{agent_type}.pth"
    agent.save(model_path)
    print(f"Model saved to {model_path}")
    
    # Save training data
    save_results(episode_rewards, episode_durations, episode_losses,
                config, env_name, agent_type)
    
    # Plot results
    plot_path = f"results/{env_name}_{agent_type}_plot.png"
    plot_training_results(episode_rewards, episode_durations,
                         f"{env_name} - {agent_type}", save_path=plot_path)
    
    if use_wandb and WANDB_AVAILABLE:
        wandb.finish()
    
    env.close()
    return agent


def main():
    """Main function to train agents"""
    parser = argparse.ArgumentParser(description='Train DQN/DDQN on classical environments')
    parser.add_argument('--env', type=str, default='CartPole-v1',
                       choices=['CartPole-v1', 'Acrobot-v1', 'MountainCar-v0', 'Pendulum-v1'],
                       help='Environment name')
    parser.add_argument('--agent', type=str, default='DQN',
                       choices=['DQN', 'DDQN'],
                       help='Agent type')
    parser.add_argument('--wandb', action='store_true',
                       help='Use Weights & Biases for logging')
    parser.add_argument('--all', action='store_true',
                       help='Train on all environments with both agents')
    
    args = parser.parse_args()
    
    if args.all:
        # Train all combinations
        environments = ['CartPole-v1', 'Acrobot-v1', 'MountainCar-v0', 'Pendulum-v1']
        agents = ['DQN', 'DDQN']
        
        for env_name in environments:
            for agent_type in agents:
                print(f"\n{'='*70}")
                print(f"Training {agent_type} on {env_name}")
                print(f"{'='*70}\n")
                train_agent(env_name, agent_type, use_wandb=args.wandb)
    else:
        # Train single configuration
        train_agent(args.env, args.agent, use_wandb=args.wandb)


if __name__ == "__main__":
    main()

"""
Double Deep Q-Network (DDQN) Agent
"""
import torch
import torch.nn as nn
import numpy as np
from dqn_agent import DQNAgent


class DDQNAgent(DQNAgent):
    """
    Double DQN Agent - extends DQN to reduce overestimation bias.
    
    Key difference from DQN:
    - DQN: Q_target = r + gamma * max_a' Q_target(s', a')
    - DDQN: Q_target = r + gamma * Q_target(s', argmax_a' Q_policy(s', a'))
    
    DDQN uses the policy network to SELECT the best action,
    but uses the target network to EVALUATE that action.
    This decoupling reduces overestimation of Q-values.
    """
    
    def __init__(self, state_dim, action_dim, config, device='cpu'):
        """
        Initialize DDQN Agent (inherits from DQN)
        
        Args:
            state_dim (int): Dimension of state space
            action_dim (int): Dimension of action space
            config (dict): Configuration dictionary with hyperparameters
            device (str): Device to run on ('cpu' or 'cuda')
        """
        super().__init__(state_dim, action_dim, config, device)
    
    def train(self):
        """
        Train the agent using Double Q-Learning
        
        Returns:
            float: Loss value (None if not enough samples or not time to train)
        """
        # Don't train until we have enough samples
        if len(self.memory) < self.learning_starts:
            return None
        
        # Only train every train_freq steps
        if self.steps % self.train_freq != 0:
            return None
        
        # Sample batch from replay buffer
        states, actions, rewards, next_states, dones = self.memory.sample(self.batch_size)
        
        # Convert to tensors
        states = torch.FloatTensor(states).to(self.device)
        actions = torch.LongTensor(actions).to(self.device)
        rewards = torch.FloatTensor(rewards).to(self.device)
        next_states = torch.FloatTensor(next_states).to(self.device)
        dones = torch.FloatTensor(dones).to(self.device)
        
        # Compute Q(s_t, a)
        current_q_values = self.policy_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)
        
        # Double Q-Learning: Select action using policy net, evaluate using target net
        with torch.no_grad():
            # Select best actions using policy network
            next_actions = self.policy_net(next_states).argmax(1)
            # Evaluate those actions using target network
            next_q_values = self.target_net(next_states).gather(1, next_actions.unsqueeze(1)).squeeze(1)
            # Clip next_q_values to prevent explosion
            next_q_values = torch.clamp(next_q_values, -500, 500)
            # Q-learning target
            target_q_values = rewards + (1 - dones) * self.gamma * next_q_values
            # Clip target Q-values as additional safety
            target_q_values = torch.clamp(target_q_values, -500, 500)
        
        # Compute loss
        loss = self.criterion(current_q_values, target_q_values)
        
        # Optimize the model
        self.optimizer.zero_grad()
        loss.backward()
        # Clip gradients
        torch.nn.utils.clip_grad_norm_(self.policy_net.parameters(), self.gradient_clip)
        self.optimizer.step()
        
        # Increment update counter
        self.num_param_updates += 1
        
        # Decay epsilon after each training step
        self.epsilon = max(self.epsilon_end, self.epsilon * self.epsilon_decay)
        
        # Update target network
        if self.num_param_updates % self.target_update == 0:
            self.update_target_network()
        
        return loss.item()

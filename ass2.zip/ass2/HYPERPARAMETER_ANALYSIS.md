# Hyperparameter Tuning Analysis

## Overview

This document summarizes the hyperparameter experiments conducted during training DQN and DDQN agents on classical control environments.

---

## Hyperparameters Tested

### 1. **Learning Rate**

- **Values Tested**: 0.001, 0.0005, 0.0001
- **Impact**:
  - Higher LR (0.001): Faster convergence but risk of instability
  - Lower LR (0.0005): More stable, especially for Pendulum
  - Too low (0.0001): Slow convergence

**Best Values:**

- CartPole-v1: 0.001
- Acrobot-v1: 0.001
- MountainCar-v0: 0.001
- Pendulum-v1: 0.0005 (continuous control requires lower LR)

### 2. **Epsilon Decay Rate**

- **Values Tested**: 0.995, 0.9995, 0.9999
- **Impact**:
  - Fast decay (0.995): Quick exploitation, risk of premature convergence
  - Slow decay (0.9999): Maintains exploration longer, critical for MountainCar

**Best Values:**

- CartPole-v1: 0.995 (quick convergence)
- Acrobot-v1: 0.995 (dense rewards)
- MountainCar-v0: 0.9999 (sparse rewards need more exploration)
- Pendulum-v1: 0.998 (balance exploration/exploitation)

### 3. **Epsilon End (Minimum Exploration)**

- **Values Tested**: 0.01, 0.02, 0.05, 0.10
- **Impact**:
  - Low (0.01): Pure exploitation after decay
  - High (0.10): Maintains 10% random exploration indefinitely

**Best Values:**

- CartPole-v1: 0.01 (deterministic policy preferred)
- Acrobot-v1: 0.01
- MountainCar-v0: 0.10 (sparse rewards need continuous exploration)
- Pendulum-v1: 0.02 (slight exploration helps)

### 4. **Target Network Update Frequency**

- **Values Tested**: 10, 50, 100 steps
- **Impact**:
  - Frequent updates (10): More responsive but less stable
  - Infrequent updates (100): More stable but slower adaptation

**Best Values:**

- CartPole-v1: 10 (fast environment)
- Acrobot-v1: 10 (benefits from responsiveness)
- MountainCar-v0: 100 (stability over speed)
- Pendulum-v1: 50 (balance)

### 5. **Gradient Clipping**

- **Values Tested**: 1.0, 5.0, 10.0
- **Impact**:
  - Too strict (1.0): Prevents learning, reward stuck at ~221
  - Too loose (10.0+): Risk of gradient explosion
  - Optimal (5.0-10.0): Balances stability and learning

**Discovery:** Essential for preventing catastrophic forgetting!

**Best Values:**

- CartPole-v1: 5.0
- Acrobot-v1: 5.0
- MountainCar-v0: 10.0
- Pendulum-v1: 10.0

### 6. **Replay Buffer Size**

- **Values Tested**: 10,000, 50,000, 100,000
- **Impact**:
  - Small buffer: Faster updates but less diverse experience
  - Large buffer: More stable but slower initial learning

**Best Values:**

- CartPole-v1: 10,000 (simple environment)
- Acrobot-v1: 10,000
- MountainCar-v0: 50,000 (needs diverse exploration data)
- Pendulum-v1: 50,000

### 7. **Batch Size**

- **Values Tested**: 32, 64, 128
- **Impact**:
  - Small (32): More frequent updates, noisier gradients
  - Large (128): Smoother gradients, slower updates

**Best Values:**

- All environments: 64 (good balance)

### 8. **Network Architecture (Hidden Dimensions)**

- **Values Tested**: 128, 256
- **Impact**:
  - Larger network (256): More capacity for complex environments
  - Smaller network (128): Sufficient for simple tasks

**Best Values:**

- CartPole-v1: 128 (simple state space)
- Acrobot-v1: 128
- MountainCar-v0: 256 (needs capacity to learn sparse reward patterns)
- Pendulum-v1: 128

---

## Key Discoveries

### 1. **Q-Value Clipping Critical**

- **Problem**: Loss exploded to 42,485 in CartPole causing catastrophic forgetting
- **Solution**: Implemented `torch.clamp(q_values, -500, 500)`
- **Impact**: Prevented Q-value divergence across all environments

### 2. **Environment-Specific Tuning**

Different environments require dramatically different hyperparameters:

| Environment | Key Requirement            | Reason                           |
| ----------- | -------------------------- | -------------------------------- |
| CartPole    | Gradient clipping          | Prevents catastrophic forgetting |
| Acrobot     | Default settings work well | Dense rewards naturally stable   |
| MountainCar | High exploration (ε=0.10)  | Sparse rewards require discovery |
| Pendulum    | Lower learning rate        | Continuous control sensitivity   |

### 3. **DDQN Reduces Hyperparameter Sensitivity**

DDQN showed more stable performance across hyperparameter ranges:

- CartPole: No catastrophic forgetting regardless of settings
- Pendulum: 53% variance reduction with same hyperparameters
- Less sensitive to gradient clipping values

---

## Experimental Process

### Phase 1: Initial Failures

- CartPole loss diverged to billions → Added Q-value clipping
- Loss dropped to 0.02 too fast → Agent stuck at suboptimal policy
- Extended training (1000 episodes) revealed catastrophic forgetting

### Phase 2: Stability Solutions

- Implemented gradient clipping: Tried 1.0 (too strict) → 5.0 (optimal)
- Added Q-value clipping: ±500 threshold
- Tuned learning rates per environment

### Phase 3: Environment-Specific Optimization

- CartPole: Focus on preventing forgetting
- Acrobot: Minimal tuning needed (already worked)
- MountainCar: Dramatically increased exploration parameters
- Pendulum: Balanced learning rate and discretization

---

## Recommendations

### For Future Experiments:

1. **Always start with Q-value clipping** (±500 is a good default)
2. **Use gradient clipping** (5.0-10.0 range)
3. **Test DDQN first** - more forgiving to hyperparameter choices
4. **Environment analysis before tuning**:
   - Dense rewards → Use defaults
   - Sparse rewards → Increase exploration
   - High variance → Lower learning rate
5. **Extended training** - Some environments need 500+ episodes to reveal issues

### Hyperparameter Priority:

1. **Critical**: Q-value clipping, gradient clipping
2. **High Impact**: Learning rate, epsilon decay
3. **Moderate Impact**: Target update frequency, buffer size
4. **Low Impact**: Batch size, network architecture (for these simple tasks)

---

## Conclusion

Successful RL training requires:

1. **Algorithm choice** (DDQN > DQN for stability)
2. **Stability mechanisms** (Q-value clipping, gradient clipping)
3. **Environment-specific tuning** (no one-size-fits-all)
4. **Patient experimentation** (catastrophic failures can emerge late)

The combination of DDQN + Q-value clipping + environment-tuned hyperparameters produced stable, high-performing agents across all test environments.

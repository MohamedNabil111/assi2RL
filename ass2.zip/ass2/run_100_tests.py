"""
Run 100 test episodes per trained agent and track episode durations.
This fulfills Assignment Requirement #7.
"""
import gymnasium as gym
import torch
import numpy as np
from pathlib import Path
import json
from tqdm import tqdm

from dqn_agent import DQNAgent
from ddqn_agent import DDQNAgent
from config import ENV_CONFIGS
from utils import PendulumDiscretizer


def test_agent(env_name, agent_type='DQN', n_episodes=100):
    """
    Test trained agent for n_episodes and track episode durations.
    
    Args:
        env_name (str): Environment name
        agent_type (str): 'DQN' or 'DDQN'
        n_episodes (int): Number of test episodes
        
    Returns:
        dict: Test results with rewards, durations, and statistics
    """
    print(f"\n{'='*70}")
    print(f"Testing {env_name} - {agent_type}")
    print(f"{'='*70}")
    
    # Set device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # Create environment
    env = gym.make(env_name)
    
    # Handle Pendulum's continuous action space
    if env_name == 'Pendulum-v1':
        n_actions = ENV_CONFIGS[env_name]['n_actions']
        env = PendulumDiscretizer(env, n_actions=n_actions)
        action_dim = n_actions
    else:
        action_dim = env.action_space.n
    
    state_dim = env.observation_space.shape[0]
    config = ENV_CONFIGS[env_name]
    
    # Create and load agent
    if agent_type == 'DQN':
        agent = DQNAgent(state_dim, action_dim, config, device=device)
    else:
        agent = DDQNAgent(state_dim, action_dim, config, device=device)
    
    # Load trained model
    model_path = Path(f"models/{env_name}_{agent_type}.pth")
    if not model_path.exists():
        print(f"❌ Model not found: {model_path}")
        return None
    
    # Load checkpoint and extract policy network weights
    checkpoint = torch.load(model_path, map_location=device)
    agent.policy_net.load_state_dict(checkpoint['policy_net_state_dict'])
    agent.policy_net.eval()
    print(f"✅ Loaded model from {model_path}")
    
    # Run test episodes
    episode_rewards = []
    episode_durations = []
    
    print(f"\nRunning {n_episodes} test episodes...")
    for episode in tqdm(range(n_episodes), desc="Testing"):
        state, _ = env.reset()
        episode_reward = 0
        steps = 0
        done = False
        
        while not done:
            # Select action greedily (no exploration)
            with torch.no_grad():
                action = agent.select_action(state, training=False)  # Greedy policy
            
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            episode_reward += reward
            steps += 1
            state = next_state
        
        episode_rewards.append(episode_reward)
        episode_durations.append(steps)
    
    env.close()
    
    # Calculate statistics
    mean_reward = np.mean(episode_rewards)
    std_reward = np.std(episode_rewards)
    mean_duration = np.mean(episode_durations)
    std_duration = np.std(episode_durations)
    min_duration = np.min(episode_durations)
    max_duration = np.max(episode_durations)
    
    # Print results
    print(f"\n{'='*70}")
    print(f"TEST RESULTS - {env_name} - {agent_type}")
    print(f"{'='*70}")
    print(f"Episodes Tested:      {n_episodes}")
    print(f"Mean Reward:          {mean_reward:.2f} ± {std_reward:.2f}")
    print(f"Mean Duration:        {mean_duration:.2f} ± {std_duration:.2f} steps")
    print(f"Duration Range:       [{min_duration}, {max_duration}] steps")
    print(f"Best Episode Reward:  {max(episode_rewards):.2f}")
    print(f"Worst Episode Reward: {min(episode_rewards):.2f}")
    print(f"{'='*70}\n")
    
    # Prepare results
    results = {
        'env_name': env_name,
        'agent_type': agent_type,
        'n_episodes': n_episodes,
        'episode_rewards': episode_rewards,
        'episode_durations': episode_durations,
        'statistics': {
            'mean_reward': float(mean_reward),
            'std_reward': float(std_reward),
            'mean_duration': float(mean_duration),
            'std_duration': float(std_duration),
            'min_duration': int(min_duration),
            'max_duration': int(max_duration),
            'best_reward': float(max(episode_rewards)),
            'worst_reward': float(min(episode_rewards))
        }
    }
    
    return results


def save_test_results(results, output_dir='test_results'):
    """Save test results to JSON and NPZ files."""
    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True)
    
    env_name = results['env_name']
    agent_type = results['agent_type']
    
    # Save as JSON (human-readable)
    json_path = output_dir / f"{env_name}_{agent_type}_test.json"
    with open(json_path, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"✅ Saved JSON results: {json_path}")
    
    # Save as NPZ (for analysis)
    npz_path = output_dir / f"{env_name}_{agent_type}_test.npz"
    np.savez(
        npz_path,
        episode_rewards=np.array(results['episode_rewards']),
        episode_durations=np.array(results['episode_durations']),
        statistics=results['statistics']
    )
    print(f"✅ Saved NPZ results: {npz_path}")


def create_summary_table(test_results_list):
    """Create a summary table of all test results."""
    print("\n" + "="*100)
    print("SUMMARY TABLE: 100-Episode Test Results")
    print("="*100)
    print(f"{'Environment':<20} {'Agent':<8} {'Mean Reward':<15} {'Mean Duration':<18} {'Duration Range':<20}")
    print("-"*100)
    
    for results in test_results_list:
        if results is None:
            continue
        env = results['env_name']
        agent = results['agent_type']
        stats = results['statistics']
        
        mean_reward = f"{stats['mean_reward']:.2f} ± {stats['std_reward']:.2f}"
        mean_duration = f"{stats['mean_duration']:.2f} ± {stats['std_duration']:.2f}"
        duration_range = f"[{stats['min_duration']}, {stats['max_duration']}]"
        
        print(f"{env:<20} {agent:<8} {mean_reward:<15} {mean_duration:<18} {duration_range:<20}")
    
    print("="*100)


def main():
    """Run 100 test episodes for all trained agents."""
    print("\n" + "🎯" * 35)
    print("ASSIGNMENT REQUIREMENT #7: Run 100 Test Episodes Per Environment")
    print("🎯" * 35)
    
    environments = ['CartPole-v1', 'Acrobot-v1', 'MountainCar-v0', 'Pendulum-v1']
    agents = ['DQN', 'DDQN']
    
    all_results = []
    
    for env_name in environments:
        for agent_type in agents:
            results = test_agent(env_name, agent_type, n_episodes=100)
            if results:
                save_test_results(results)
                all_results.append(results)
    
    # Create summary table
    create_summary_table(all_results)
    
    print("\n✅ All 100-episode tests completed!")
    print("📁 Results saved in: test_results/")
    print("\n📊 Total episodes run: 100 × 4 environments × 2 agents = 800 test episodes")


if __name__ == "__main__":
    main()

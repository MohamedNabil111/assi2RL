"""
W&B Quickstart Demo - Testing API Integration
"""
import wandb
import random
import numpy as np

# Initialize a new run
wandb.init(
    project="rl-assignment2-quickstart",
    name="quickstart-demo",
    config={
        "learning_rate": 0.001,
        "epochs": 10,
        "batch_size": 32,
    }
)

# Simulate training loop
print("Running W&B Quickstart Demo...")
for epoch in range(10):
    # Simulate some metrics
    acc = 0.5 + 0.5 * (epoch / 10) + random.uniform(-0.1, 0.1)
    loss = 2.0 - 1.8 * (epoch / 10) + random.uniform(-0.2, 0.2)
    
    # Log metrics to W&B
    wandb.log({
        "epoch": epoch,
        "accuracy": acc,
        "loss": loss,
        "random_metric": np.sin(epoch)
    })
    
    print(f"Epoch {epoch+1}/10 - Loss: {loss:.4f}, Accuracy: {acc:.4f}")

print("\n✅ W&B Quickstart Demo Complete!")
print(f"📊 View your results at: {wandb.run.get_url()}")

# Finish the run
wandb.finish()

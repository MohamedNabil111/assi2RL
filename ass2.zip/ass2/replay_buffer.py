"""
Experience Replay Buffer for DQN/DDQN
"""
import random
from collections import deque, namedtuple
import numpy as np


# Define experience tuple
Experience = namedtuple('Experience', ['state', 'action', 'reward', 'next_state', 'done'])


class ReplayBuffer:
    """
    Fixed-size buffer to store experience tuples for experience replay.
    
    Experience replay breaks correlation between consecutive samples and
    improves data efficiency by reusing past experiences.
    """
    
    def __init__(self, capacity):
        """
        Initialize replay buffer
        
        Args:
            capacity (int): Maximum size of buffer
        """
        self.buffer = deque(maxlen=capacity)
    
    def push(self, state, action, reward, next_state, done):
        """
        Add a new experience to memory
        
        Args:
            state: Current state
            action: Action taken
            reward: Reward received
            next_state: Next state
            done: Whether episode terminated
        """
        experience = Experience(state, action, reward, next_state, done)
        self.buffer.append(experience)
    
    def sample(self, batch_size):
        """
        Randomly sample a batch of experiences from memory
        
        Args:
            batch_size (int): Size of batch to sample
            
        Returns:
            tuple: Batch of (states, actions, rewards, next_states, dones)
        """
        experiences = random.sample(self.buffer, batch_size)
        
        states = np.array([e.state for e in experiences])
        actions = np.array([e.action for e in experiences])
        rewards = np.array([e.reward for e in experiences])
        next_states = np.array([e.next_state for e in experiences])
        dones = np.array([e.done for e in experiences])
        
        return states, actions, rewards, next_states, dones
    
    def __len__(self):
        """Return current size of buffer"""
        return len(self.buffer)

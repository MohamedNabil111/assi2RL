"""
Utility functions for training and evaluation
"""
import numpy as np
import matplotlib.pyplot as plt
import os


def plot_training_results(rewards, episode_durations, title, save_path=None):
    """
    Plot training rewards and episode durations
    
    Args:
        rewards (list): List of episode rewards
        episode_durations (list): List of episode durations
        title (str): Title for the plots
        save_path (str): Path to save the figure (optional)
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    # Plot rewards
    ax1.plot(rewards, alpha=0.6, label='Episode Reward')
    
    # Plot moving average
    if len(rewards) >= 10:
        moving_avg = np.convolve(rewards, np.ones(10)/10, mode='valid')
        ax1.plot(range(9, len(rewards)), moving_avg, 'r-', linewidth=2, label='Moving Avg (10)')
    
    ax1.set_xlabel('Episode')
    ax1.set_ylabel('Reward')
    ax1.set_title(f'{title} - Training Rewards')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # Plot episode durations
    ax2.plot(episode_durations, alpha=0.6, label='Episode Duration')
    
    # Plot moving average
    if len(episode_durations) >= 10:
        moving_avg = np.convolve(episode_durations, np.ones(10)/10, mode='valid')
        ax2.plot(range(9, len(episode_durations)), moving_avg, 'r-', linewidth=2, label='Moving Avg (10)')
    
    ax2.set_xlabel('Episode')
    ax2.set_ylabel('Duration (steps)')
    ax2.set_title(f'{title} - Episode Durations')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Plot saved to {save_path}")
    
    plt.show()


def save_results(rewards, durations, losses, config, env_name, agent_type, save_dir='results'):
    """
    Save training results to file
    
    Args:
        rewards (list): Episode rewards
        durations (list): Episode durations
        losses (list): Training losses
        config (dict): Configuration used
        env_name (str): Environment name
        agent_type (str): Agent type (DQN or DDQN)
        save_dir (str): Directory to save results
    """
    os.makedirs(save_dir, exist_ok=True)
    
    filename = os.path.join(save_dir, f'{env_name}_{agent_type}_results.npz')
    np.savez(filename,
             rewards=rewards,
             durations=durations,
             losses=losses,
             config=config)
    print(f"Results saved to {filename}")


def print_episode_stats(episode, reward, duration, epsilon, loss, interval=10):
    """
    Print episode statistics
    
    Args:
        episode (int): Episode number
        reward (float): Episode reward
        duration (int): Episode duration
        epsilon (float): Current epsilon value
        loss (float): Average loss
        interval (int): Print every N episodes
    """
    if episode % interval == 0 or episode == 1:
        loss_str = f"{loss:.4f}" if loss else "0.0000"
        print(f"Episode {episode:4d} | "
              f"Reward: {reward:8.2f} | "
              f"Duration: {duration:4d} | "
              f"Epsilon: {epsilon:.3f} | "
              f"Loss: {loss_str}")


def evaluate_agent(agent, env, n_episodes=10):
    """
    Evaluate trained agent
    
    Args:
        agent: Trained agent
        env: Gym environment
        n_episodes (int): Number of evaluation episodes
        
    Returns:
        tuple: (mean_reward, std_reward, mean_duration)
    """
    rewards = []
    durations = []
    
    for _ in range(n_episodes):
        state, _ = env.reset()
        episode_reward = 0
        episode_duration = 0
        done = False
        
        while not done:
            action = agent.select_action(state, training=False)
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            
            episode_reward += reward
            episode_duration += 1
            state = next_state
        
        rewards.append(episode_reward)
        durations.append(episode_duration)
    
    return np.mean(rewards), np.std(rewards), np.mean(durations)


class PendulumDiscretizer:
    """
    Wrapper to discretize Pendulum-v1 continuous action space
    """
    def __init__(self, env, n_actions=25):
        """
        Initialize discretizer
        
        Args:
            env: Gym environment
            n_actions (int): Number of discrete actions
        """
        self.env = env
        self.n_actions = n_actions
        # Pendulum action space is [-2, 2]
        self.action_values = np.linspace(-2, 2, n_actions)
        
    def reset(self, **kwargs):
        """Reset environment"""
        return self.env.reset(**kwargs)
    
    def step(self, action):
        """
        Take discrete action, convert to continuous
        
        Args:
            action (int): Discrete action index
            
        Returns:
            tuple: (state, reward, terminated, truncated, info)
        """
        continuous_action = np.array([self.action_values[action]])
        return self.env.step(continuous_action)
    
    def __getattr__(self, name):
        """Forward other attributes to wrapped environment"""
        return getattr(self.env, name)

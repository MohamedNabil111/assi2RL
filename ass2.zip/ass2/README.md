# Assignment 2: Deep Q-Network (DQN) and Double DQN (DDQN)

This project implements DQN and DDQN algorithms for solving classical control environments in Gymnasium.

## Project Structure

```
├── config.py           # Hyperparameter configurations for each environment
├── network.py          # Q-Network neural network architecture
├── replay_buffer.py    # Experience replay buffer implementation
├── dqn_agent.py        # DQN agent with experience replay and target network
├── ddqn_agent.py       # Double DQN agent (extends DQN)
├── utils.py            # Utility functions for plotting and evaluation
├── train.py            # Main training script
├── gym_env.py          # Script to run and record trained agents
├── requirements.txt    # Python dependencies
└── README.md          # This file
```

## Architecture Explanation

### 1. **QNetwork (network.py)**

- **Purpose**: Approximates the Q-value function Q(s, a)
- **Architecture**:
  - Input layer: state_dim neurons
  - Hidden layer 1: 128 neurons with ReLU activation
  - Hidden layer 2: 128 neurons with ReLU activation
  - Output layer: action_dim neurons (Q-value for each action)

### 2. **ReplayBuffer (replay_buffer.py)**

- **Purpose**: Stores past experiences for training
- **Key Methods**:
  - `push()`: Add new experience (s, a, r, s', done)
  - `sample()`: Randomly sample a batch for training
- **Why**: Breaks correlation between consecutive samples, improves stability

### 3. **DQNAgent (dqn_agent.py)**

- **Key Components**:
  - **Policy Network**: Used for action selection and training
  - **Target Network**: Fixed copy of policy network, provides stable Q-targets
  - **Replay Buffer**: Stores experiences
  - **Epsilon-Greedy**: Balances exploration vs exploitation
- **Key Methods**:
  - `select_action()`: Choose action using epsilon-greedy policy
  - `train()`: Sample batch, compute loss, update policy network
  - `update_target_network()`: Copy weights from policy to target network
- **Training Process**:
  1. Select action using epsilon-greedy policy
  2. Execute action, observe reward and next state
  3. Store transition in replay buffer
  4. Sample random batch from buffer
  5. Compute Q-targets: `r + γ * max_a' Q_target(s', a')`
  6. Update policy network to minimize MSE between Q-values and targets
  7. Periodically update target network

### 4. **DDQNAgent (ddqn_agent.py)**

- **Extends DQN** to reduce Q-value overestimation
- **Key Difference**:
  - DQN: `Q_target = r + γ * max_a' Q_target(s', a')`
  - DDQN: `Q_target = r + γ * Q_target(s', argmax_a' Q_policy(s', a'))`
- **Why Better**: Decouples action selection from evaluation, reducing bias

### 5. **Training Script (train.py)**

- Main training loop for all environments
- Integrates with Weights & Biases for experiment tracking
- Saves models, plots, and training data
- Evaluates final agent performance

### 6. **Environment Runner (gym_env.py)**

- Records videos of trained agents
- Provides interactive visualization mode
- Handles continuous action spaces (Pendulum)

## Installation

```bash
pip install -r requirements.txt
```

## Usage

### Train a Single Agent

```bash
# Train DQN on CartPole
python train.py --env CartPole-v1 --agent DQN

# Train DDQN on Acrobot
python train.py --env Acrobot-v1 --agent DDQN

# Train with Weights & Biases logging
python train.py --env MountainCar-v0 --agent DQN --wandb
```

### Train on All Environments

```bash
# Train both DQN and DDQN on all 4 environments
python train.py --all

# With Weights & Biases
python train.py --all --wandb
```

### Record Trained Agent

```bash
# Record video
python gym_env.py --env CartPole-v1 --agent DQN --mode record --episodes 3

# Run interactively
python gym_env.py --env CartPole-v1 --agent DQN --mode interactive
```

## Environments

1. **CartPole-v1**: Balance a pole on a cart
2. **Acrobot-v1**: Swing up a two-link pendulum
3. **MountainCar-v0**: Drive up a steep hill
4. **Pendulum-v1**: Keep pendulum upright (continuous actions discretized)

## Hyperparameters

Default hyperparameters are in `config.py`. Key parameters:

- **Learning Rate (lr)**: 0.0005 - 0.001
- **Discount Factor (γ)**: 0.99
- **Epsilon Decay**: 0.995 (exploration decreases over time)
- **Batch Size**: 64
- **Replay Memory Size**: 10,000
- **Target Network Update**: Every 10 training steps
- **Hidden Dimension**: 128 neurons

## Results

After training, you'll find:

- `models/`: Saved model checkpoints
- `results/`: Training plots and data (rewards, durations, losses)
- `videos/`: Recorded videos of trained agents

## Weights & Biases Integration

To track experiments with W&B:

1. Sign up at https://wandb.ai/
2. Login: `wandb login`
3. Run with `--wandb` flag

Tracked metrics:

- Episode reward
- Episode duration
- Epsilon (exploration rate)
- Training loss
- Evaluation statistics

## Key Concepts

### Experience Replay

- Stores past experiences in replay buffer
- Samples random batches for training
- Breaks temporal correlation between samples
- Improves data efficiency

### Target Network

- Separate network with frozen weights
- Provides stable Q-targets during training
- Updated periodically (every 10 steps)
- Prevents divergence

### Epsilon-Greedy Exploration

- With probability ε: random action (explore)
- With probability 1-ε: best action (exploit)
- ε decays over time (1.0 → 0.01)
- Balances exploration vs exploitation

### Double Q-Learning (DDQN)

- Uses policy network to SELECT action
- Uses target network to EVALUATE action
- Reduces overestimation bias
- Generally more stable than DQN

## Assignment Questions Guide

1. **Training time and performance**: Compare DQN vs DDQN using saved plots
2. **Stability**: Analyze episode duration figures (test performance)
3. **Hyperparameter effects**: Modify config.py and retrain
4. **Why DQN/DDQN works**: Explain experience replay and target networks

## Tips

- CartPole converges fastest (~200-300 episodes)
- MountainCar is hardest (needs ~800-1000 episodes)
- DDQN usually more stable than DQN
- Increase max_episodes if not converging
- Use `--wandb` to compare different runs

## Troubleshooting

- **Low rewards**: Increase max_episodes or adjust learning rate
- **Unstable training**: Reduce learning rate or increase target_update frequency
- **Memory error**: Reduce batch_size or memory_size
- **Slow training**: Use GPU if available (automatic detection)

## Author

CMP5458: Reinforcement Learning - Fall 2025
Ayman AboElHassan, PhD

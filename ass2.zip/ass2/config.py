"""
Configuration file for DQN/DDQN hyperparameters
"""

# Environment configurations for classical control tasks
ENV_CONFIGS = {
    'CartPole-v1': {
        'lr': 0.001,
        'gamma': 0.99,
        'epsilon_start': 1.0,
        'epsilon_end': 0.01,
        'epsilon_decay': 0.995,
        'batch_size': 64,
        'memory_size': 10000,
        'target_update': 10,
        'hidden_dim': 128,
        'max_episodes': 500,  # Shorter training to avoid late degradation
        'max_steps': 500,
        'learning_starts': 1000,
        'train_freq': 4,
        'gradient_clip': 10.0  # Original setting with Q-clipping
    },
    'Acrobot-v1': {
        'lr': 0.001,  # Higher LR - Acrobot needs faster learning
        'gamma': 0.99,
        'epsilon_start': 1.0,
        'epsilon_end': 0.01,
        'epsilon_decay': 0.995,
        'batch_size': 64,
        'memory_size': 20000,  # Moderate buffer
        'target_update': 10,  # More frequent updates like CartPole
        'hidden_dim': 128,
        'max_episodes': 500,  # Needs more episodes than CartPole
        'max_steps': 500,
        'learning_starts': 1000,
        'train_freq': 4,
        'gradient_clip': 10.0
    },
    'MountainCar-v0': {
        'lr': 0.001,
        'gamma': 0.99,
        'epsilon_start': 1.0,
        'epsilon_end': 0.10,  # Keep 10% exploration!
        'epsilon_decay': 0.9999,  # Very slow decay
        'batch_size': 32,
        'memory_size': 50000,
        'target_update': 100,
        'hidden_dim': 256,  # Larger network
        'max_episodes': 1000,  # MUCH longer training!
        'max_steps': 200,
        'learning_starts': 5000,  # Wait even longer
        'train_freq': 1,  # Train every step
        'gradient_clip': 10.0
    },
    'Pendulum-v1': {
        'lr': 0.0005,
        'gamma': 0.99,
        'epsilon_start': 1.0,
        'epsilon_end': 0.02,  # Keep more exploration - discretized actions
        'epsilon_decay': 0.995,  # Faster decay - simpler than MountainCar
        'batch_size': 64,
        'memory_size': 20000,  # Moderate buffer
        'target_update': 50,  # Medium update frequency
        'hidden_dim': 128,
        'max_episodes': 400,  # Converges faster than others
        'max_steps': 200,
        'n_actions': 25,  # Discretize continuous action space
        'learning_starts': 1000,
        'train_freq': 4,
        'gradient_clip': 10.0
    }
}
